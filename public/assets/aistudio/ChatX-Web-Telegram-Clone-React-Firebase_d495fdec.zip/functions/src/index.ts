import * as admin from 'firebase-admin';
import { onDocumentCreated } from 'firebase-functions/v2/firestore';

admin.initializeApp();

// Sends a push notification to all chat members (except the sender) when a
// new message is created. Requires each user doc to have an `fcmTokens: string[]`
// field populated client-side via getToken() from firebase/messaging.
export const onNewMessage = onDocumentCreated(
  'chats/{chatId}/messages/{messageId}',
  async (event) => {
    const message = event.data?.data();
    const { chatId } = event.params;
    if (!message) return;

    const chatSnap = await admin.firestore().doc(`chats/${chatId}`).get();
    const chat = chatSnap.data();
    if (!chat) return;

    const recipientIds: string[] = chat.memberIds.filter(
      (uid: string) => uid !== message.senderId,
    );

    const tokens: string[] = [];
    for (const uid of recipientIds) {
      const userSnap = await admin.firestore().doc(`users/${uid}`).get();
      const userTokens: string[] = userSnap.data()?.fcmTokens || [];
      tokens.push(...userTokens);
    }
    if (tokens.length === 0) return;

    const body =
      message.type === 'text' ? message.text : `Sent a ${message.type}`;

    await admin.messaging().sendEachForMulticast({
      tokens,
      notification: {
        title: chat.name,
        body,
      },
      data: { chatId },
    });
  },
);
