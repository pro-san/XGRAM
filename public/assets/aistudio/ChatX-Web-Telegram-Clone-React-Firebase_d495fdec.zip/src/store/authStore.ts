import { create } from 'zustand';
import { onAuthStateChanged, type User } from 'firebase/auth';
import { doc, onSnapshot } from 'firebase/firestore';
import { auth, db } from '../firebase/config';
import type { AppUser } from '../types';

interface AuthState {
  firebaseUser: User | null;
  profile: AppUser | null;
  loading: boolean;
  init: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  firebaseUser: null,
  profile: null,
  loading: true,
  init: () => {
    onAuthStateChanged(auth, (user) => {
      set({ firebaseUser: user, loading: false });
      if (user) {
        onSnapshot(doc(db, 'users', user.uid), (snap) => {
          if (snap.exists()) {
            set({ profile: { uid: snap.id, ...snap.data() } as AppUser });
          }
        });
      } else {
        set({ profile: null });
      }
    });
  },
}));
