import {
  addDoc,
  collection,
  doc,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  limit,
  arrayUnion,
} from 'firebase/firestore';
import { db } from './config';
import type { Chat, ChatType, Message, MessageType } from '../types';

export function subscribeToUserChats(
  uid: string,
  callback: (chats: Chat[]) => void,
) {
  const q = query(
    collection(db, 'chats'),
    where('memberIds', 'array-contains', uid),
    orderBy('lastMessage.createdAt', 'desc'),
  );
  return onSnapshot(q, (snap) => {
    const chats = snap.docs.map((d) => ({ id: d.id, ...d.data() }) as Chat);
    callback(chats);
  });
}

export function subscribeToMessages(
  chatId: string,
  callback: (messages: Message[]) => void,
) {
  const q = query(
    collection(db, 'chats', chatId, 'messages'),
    orderBy('createdAt', 'asc'),
    limit(500),
  );
  return onSnapshot(q, (snap) => {
    const messages = snap.docs.map(
      (d) => ({ id: d.id, ...d.data() }) as Message,
    );
    callback(messages);
  });
}

export async function createChat(opts: {
  type: ChatType;
  name: string;
  memberIds: string[];
  createdBy: string;
  photoURL?: string;
  isBroadcastOnly?: boolean;
}) {
  const ref = await addDoc(collection(db, 'chats'), {
    type: opts.type,
    name: opts.name,
    photoURL: opts.photoURL || '',
    memberIds: opts.memberIds,
    adminIds: [opts.createdBy],
    createdBy: opts.createdBy,
    createdAt: serverTimestamp(),
    isBroadcastOnly: opts.isBroadcastOnly || opts.type === 'channel',
  });
  return ref.id;
}

export async function sendMessage(opts: {
  chatId: string;
  senderId: string;
  type: MessageType;
  text?: string;
  mediaUrl?: string;
  mediaName?: string;
  mediaSize?: number;
  voiceDurationSec?: number;
}) {
  const messagesRef = collection(db, 'chats', opts.chatId, 'messages');
  await addDoc(messagesRef, {
    senderId: opts.senderId,
    type: opts.type,
    text: opts.text || '',
    mediaUrl: opts.mediaUrl || '',
    mediaName: opts.mediaName || '',
    mediaSize: opts.mediaSize || 0,
    voiceDurationSec: opts.voiceDurationSec || 0,
    createdAt: serverTimestamp(),
    readBy: [opts.senderId],
    deleted: false,
  });

  const chatRef = doc(db, 'chats', opts.chatId);
  await updateDoc(chatRef, {
    lastMessage: {
      text: opts.type === 'text' ? opts.text : `[${opts.type}]`,
      senderId: opts.senderId,
      type: opts.type,
      createdAt: serverTimestamp(),
    },
  });
}

export async function markMessageRead(
  chatId: string,
  messageId: string,
  uid: string,
) {
  const ref = doc(db, 'chats', chatId, 'messages', messageId);
  await updateDoc(ref, { readBy: arrayUnion(uid) });
}

export async function setTyping(chatId: string, uid: string, isTyping: boolean) {
  const ref = doc(db, 'chats', chatId, 'typing', uid);
  await setDoc(
    ref,
    { uid, isTyping, updatedAt: serverTimestamp() },
    { merge: true },
  );
}

export function subscribeToTyping(
  chatId: string,
  callback: (typing: Record<string, boolean>) => void,
) {
  const q = collection(db, 'chats', chatId, 'typing');
  return onSnapshot(q, (snap) => {
    const result: Record<string, boolean> = {};
    snap.docs.forEach((d) => {
      const data = d.data();
      result[data.uid] = data.isTyping;
    });
    callback(result);
  });
}
