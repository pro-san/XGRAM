import { collection, getDocs, query, where, orderBy, limit } from 'firebase/firestore';
import { db } from './config';
import type { AppUser } from '../types';

export async function searchUsersByUsername(prefix: string): Promise<AppUser[]> {
  if (!prefix.trim()) return [];
  const q = query(
    collection(db, 'users'),
    orderBy('username'),
    where('username', '>=', prefix),
    where('username', '<=', prefix + '\uf8ff'),
    limit(10),
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => ({ uid: d.id, ...d.data() }) as AppUser);
}
