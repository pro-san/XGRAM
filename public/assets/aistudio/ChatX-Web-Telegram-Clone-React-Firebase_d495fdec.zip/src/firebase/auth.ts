import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  signOut as fbSignOut,
  updateProfile,
  type User,
} from 'firebase/auth';
import { doc, setDoc, serverTimestamp, getDoc } from 'firebase/firestore';
import { auth, db } from './config';
import type { AppUser } from '../types';

const googleProvider = new GoogleAuthProvider();

async function ensureUserDoc(user: User, extra?: Partial<AppUser>) {
  const ref = doc(db, 'users', user.uid);
  const snap = await getDoc(ref);
  if (!snap.exists()) {
    const data: Partial<AppUser> = {
      uid: user.uid,
      displayName: user.displayName || extra?.displayName || 'New User',
      username: extra?.username || user.uid.slice(0, 8),
      email: user.email || '',
      photoURL: user.photoURL || '',
      status: 'online',
      language: 'en',
      createdAt: serverTimestamp() as unknown as AppUser['createdAt'],
      lastSeen: serverTimestamp() as unknown as AppUser['lastSeen'],
      ...extra,
    };
    await setDoc(ref, data, { merge: true });
  }
}

export async function registerWithEmail(
  email: string,
  password: string,
  displayName: string,
  username: string,
) {
  const cred = await createUserWithEmailAndPassword(auth, email, password);
  await updateProfile(cred.user, { displayName });
  await ensureUserDoc(cred.user, { displayName, username });
  return cred.user;
}

export async function loginWithEmail(email: string, password: string) {
  const cred = await signInWithEmailAndPassword(auth, email, password);
  await ensureUserDoc(cred.user);
  return cred.user;
}

export async function loginWithGoogle() {
  const cred = await signInWithPopup(auth, googleProvider);
  await ensureUserDoc(cred.user);
  return cred.user;
}

export async function signOut() {
  await fbSignOut(auth);
}
